<!DOCTYPE html>
<html lang="en" >

<head>
  <meta charset="UTF-8">
  <title>Masuk</title>
  <link href='https://fonts.googleapis.com/css?family=Titillium+Web:400,300,600' rel='stylesheet' type='text/css'>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/normalize/5.0.0/normalize.min.css">

  
      <link rel="stylesheet" href="./login.css">

  
</head>

<body>

  <div class="form">
      
      
        <h1 class="tab active"><a href="#signup">Masuk</a></h1>
        <div id="login">   
          <h1>Selamat Datang</h1>
          
          <form action="cek_login.php" method="post">
          
            <div class="field-wrap">
            <label>
              Username<span class="req">*</span>
            </label>
            <input type="text"required autocomplete="off" name="Username"/>
          </div>
          
          <div class="field-wrap">
            <label>
              Kata sandi<span class="req">*</span>
            </label>
            <input type="password"required autocomplete="off" name="Password"/>
          </div>
          
          <button class="button button-block" name="login" value="LOGIN"/>Masuk</button>
          
          </form>

        </div>
        
      </div><!-- tab-content -->
      
</div> <!-- /form -->
  <script src='http://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>

  

    <script  src="./script.js"></script>




</body>

</html>
