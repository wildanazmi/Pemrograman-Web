<?php 
session_start();
if(isset($_SESSION['nik']) && isset($_SESSION['kk'])){
$nik = $_SESSION['nik'];
$kk = $_SESSION['kk'];} else{
	$nik = 0;
	$kk = 0;
}
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
<title>Daftar Keluarga</title>

<style type= "text/css">
h1{
	text-align: center;
	padding-top: 50px;
	font-size: 30px;}

.table-hover{
	width: 90%;
	margin: 0 auto;
	font-family: verdana;
}
body, .main, ul, li, td{

	font-family: verdana;
}
</style>
<link rel="stylesheet" type="text/css" href="css/style.css">
</head>

<body>


		<div class="main">
			<ul>
				<li><a href="Home.php">Home</a></li>
				<li><a href="List.php">List RT / RW</a></li>
				<li><a href="Keluarga.php">Lihat Data Keluarga</a></li>
				<li><a href="arsip.php">Arsip</a></li>
				<li><a href="Iuran.php">Tagihan Iuran</a></li>
				<li><a href="mutasi.php">Mutasi</a></li>
				<li><a href="login2.php">Logout</a></li>
				<li><a href="settingpass.php">Akun</a></li>
			</ul>
		</div>
		
		<h1> Daftar Warga</h1>
	<table class="table table-hover">
  <thead>
    <tr>
      <th scope="col">Nama Anggota</th>
      <th scope="col">NIK</th>
      <th scope="col">Status</th>
      <th scope="col">TTL</th>
      <th scope="col">Nama Ibu</th>
    </tr>
  </thead>
  <tbody>
   </tbody>
	<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "rt_rw";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

$sql = $conn->query("SELECT Id_KK FROM detail_kk WHERE NIK='$nik'");
$Id_KK=$sql->fetch_assoc();
//$sql1 = "SELECT * FROM master WHERE Id_KK='$Id_KK'";
$id=$Id_KK["Id_KK"];
//printf($id);
$sql2 = $conn->query("SELECT * FROM detail_kk join master WHERE detail_kk.Id_KK='$id' && master.Id_KK='$id'");

//$result = $conn->query($sql);

//while($row = $result->fetch_assoc()) {
//	$Id_KK=$row["Id_KK"];

//}
	while($row = $sql2->fetch_assoc()){
				echo "<tr>
				<td>" . $row["nama_anggota"]. " </td>
				<td>" . $row["NIK"]. " </td>
				<td>" . $row["status_anggota"]. " </td>
				<td>" . $row["ttl"]. " </td>
				<td>" . $row["nama_ibu"]. " </td>
				</tr>";

	}
//if ($result->num_rows > 0) {
    // output data of each row
//    while($row = $result->fetch_assoc()) {
//	}
//} else {
	//printf($nama);
	//print($sql);
    //echo "0 results";
//}
//}
$conn->close();
?>
</table>
<div class="footer">
  	<p>Contact US : +62 85601754527</p>
</div>

</body>
</html>