<?php 
session_start();
$nik = $_SESSION['nik'];
$kk = $_SESSION['kk'];

?><!doctype html>
<html>
<head>
<meta charset="utf-8">
<title> Tagihan </title>

<style type= "text/css">
h1{
	text-align: center;
	padding-top: 50px;
	font-size: 30px;}

table {
	padding-top: 30px;
	width: 80%;
	align: center;
	font-family: monospace;
	font-size: 20px;
	text-align: center;
	margin: auto;}
	
th {
	background-color: #707272;
	color: white;
	padding-top: 10px;
	padding-bottom: 10px;
	padding-left: 30px;
	padding-right: 30px;} 

td {
	padding-left: 30px;
	padding-right: 30px;
	padding-top: 10px;
	padding-bottom: 10px;
	color: black;}
form {
	left: 520px;
	padding: 5px;
	position: relative;
	font-size: 50px;
}
form > h3 {
	padding: 5px;
	position: absolute;
	font-size: 15px;
}
.para {
	padding-left: 580px;
	font-size: 20px;
	padding-top: 0px;
}
.link {
	text-align: center;
	padding-top: 50px;
	padding-bottom: 0px;

}
	
</style>
<link rel="stylesheet" type="text/css" href="css/style.css">
</head>

<body>

		<div class="main">
			<ul>
				<li><a href="Home.php">Home</a></li>
				<li><a href="List.php">List RT / RW</a></li>
				<li><a href="keluarga.php">Lihat Data Keluarga</a></li>
				<li><a href="arsip.php">Arsip</a></li>
				<li><a href="Iuran.php">Tagihan Iuran</a></li>
				<li><a href="mutasi.php">Mutasi</a></li>
				<li><a href="login2.php">Logout</a>
				<li><a href="settingpass.php">Akun</a></li>

			</ul>
		</div>
		
	
	<div class="link">
	<?php
		include 'koneksi.php';
		if($_POST['upload']){
			$ekstensi_diperbolehkan	= array('png','jpg');
			$jmlh = $_POST['nominal'];
			$id_tagihan = $_POST['id_tagihan'];
			$name = $_FILES['file']['name'];
			$x = explode('.', $name);
			$ekstensi = strtolower(end($x));
			$ukuran	= $_FILES['file']['size'];
			$file_tmp = $_FILES['file']['tmp_name'];
				//uplod bukti pembayaran		

					if ($file_tmp!=null){

					move_uploaded_file($file_tmp, 'tagihan/'.$name);
			
				//input data pembayaran

					$query = "INSERT INTO upload (`id_file`,`ID_Tagihan`, `nama_file`, `tanggal`, `nominal`, `bukti`) VALUES (null,'$id_tagihan', '$name',null,'$jmlh', '$file_tmp')";
					$ins = $koneksi->query($query);
				
				//update data tagihan
					 
					
					// 
					//
					$sisa = $_POST['tagihan']-$jmlh;
					//$file_tmp = $_FILES['file']['tmp_name'];
					
					if($sisa>0){
					$query1 = "UPDATE `Tagihan` SET `Jumlah_tagihan`='$sisa' WHERE ID_Tagihan = '$id_tagihan'";
					$update=$koneksi->query($query1);
					echo "<h1>Upload Berhasil! </h1>";
					}else{
						echo "<script type='text/javascript'>alert('Nominal yang anda bayarkan terlalu banyak!');
						window.location='Iuran.php';</script>";}
					}else{
						echo "<script type='text/javascript'>alert('Lampirkan Bukti!');
						window.location='Iuran.php';</script>";
					}
				}


		?>
		</div>

		<br/>
		<br/>
		<a class="para" href="Iuran.php">Upload Lagi</a>
		<br/>
		<br/>

		<table>
			<?php 
			
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "rt_rw";
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

$sql = $conn->query("SELECT * FROM upload where nama_file='$name'");
$file=$sql->fetch_assoc();?>
			<tr>
				<td>
					<img src="tagihan/<?php echo $file['nama_file']?>"/>

				</td>		
			</tr>
		</table>
	</body>
</html>