<?php 
session_start();
$kk = $_SESSION['kk'];
?>
<!doctype html>
<html>
<head>

<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>

<title> Tagihan </title>

<style type= "text/css">

.list {
	font-size: 20px;
}
h1{
	text-align: center;
	padding-top: 50px;
	font-size: 30px;}

.table-hover{
	width: 90%;
	margin: 0 auto;
	font-family: verdana;
}
body, .main, ul, li, td{

	font-family: verdana;
}
.head{
	text-align: center;
	padding-top: 200px;
	font-family: verdana;
	font-size: 20px;
}
.form-tengah{
	width: 20%
	margin: 0 auto;
	padding-left: 540px;
}
</style>
<link rel="stylesheet" type="text/css" href="css/style.css">
</head>

<body>

		<div class="main">
			<ul>
				<li><a href="Home.php">Home</a></li>
				<li><a href="List.php">List RT / RW</a></li>
				<li><a href="keluarga.php">Lihat Data Keluarga</a></li>
				<li><a href="arsip.php">Arsip</a></li>
				<li><a href="Iuran.php">Tagihan Iuran</a></li>
				<li><a href="mutasi.php">Mutasi</a></li>
				<li><a href="login2.php">Logout</a>
				<li><a href="settingpass.php">Akun</a></li>
			</ul>
		</div>
		
		<h1> Daftar Tagihan </h1>
<table> 
<table class="table table-hover">
  <thead>
    <tr>
      <th scope="col">Nomor KK</th>
      <th scope="col">Nama Kepala Keluarga</th>
      <th scope="col">Jumlah Tagihan</th>
    </tr>
  </thead>
  <tbody>
   </tbody>

	<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "rt_rw";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

//$sql = $conn->query("SELECT Id_KK FROM detail_kk WHERE NIK='$nama'");
//$Id_KK=$sql->fetch_assoc();
//$sql1 = "SELECT * FROM master WHERE Id_KK='$Id_KK'";
//$id=$Id_KK["Id_KK"];
//printf($id);
//$sql2 = "SELECT * FROM Tagihan join master WHERE Tagihan.ID_KK='$id' && master.Id_KK='$id'";

//ambil data tagihan
$sql = $conn->query("SELECT * FROM Tagihan where No_KK='$kk'");
//$data=$sql->fetch_assoc();		
//$id_tagihan = $data['ID_Tagihan'];
//$data = $sql->fetch_assoc();
//$result = $conn->query($sql);
				
//while($row = $result->fetch_assoc()) {
//	$Id_KK=$row["Id_KK"];

//}
	while($row = $sql->fetch_assoc()){
		$id_tagihan = $row['ID_Tagihan'];
		$Jumlah_tagihan = $row["Jumlah_tagihan"];
				echo "<tr>
				<td>" . $row["No_KK"]. " </td>
				<td>" . $row["Nama_Kepala_Kel"]. " </td>
				<td>" . $row["Jumlah_tagihan"]. " </td>
				</tr>";

	}

$conn->close();
?>
</table>

<h3 class="head">Kirim Bukti Pembayaran</h3>
<div class="form-tengah" >
<form action="upload_bayar.php" method="post" enctype="multipart/form-data">
<input type="file" name="file" id='file'><br>
 <h3> Masukkan nominal:</h3>
  <input type="text" name="nominal">
  <input type="submit" name="upload" value="Submit">
  <input type="hidden" name="id_tagihan" value="<?php echo $id_tagihan?>">
  <input type="hidden" name="tagihan" value="<?php echo $Jumlah_tagihan?>">
	</form>
	</div>
</div>
<div class="footer">
  	<p>Contact US : +62 85601754527</p>
</div>
	
</body>
</html>