<?php 
// mengaktifkan session php
session_start();
 
// menghubungkan dengan koneksi
include 'koneksi.php';
				
// menangkap data yang dikirim dari form
$Username = $_POST['Username'];
$Password = $_POST['Password'];

 
// menyeleksi data admin dengan username dan password yang sesuai
$sql = "select Nama from pengguna where Username='$Username' and Password='$Password' ";
$data = mysqli_query($koneksi,$sql);
//$result1 = $koneksi->$data;	
//	while($row = $result1->fetch_assoc()){
//		$nama=$row['Nama'];
//	}

// mengambil data pengguna
$sql1 = $koneksi->query("SELECT Nama FROM Pengguna WHERE Username='$Username'");
$na=$sql1->fetch_assoc();
$nama=$na["Nama"];

//mengambil data detaik kk
$sql2 = $koneksi->query("SELECT Id_KK FROM detail_kk WHERE NIK='$Username'");
$Id_KK=$sql2->fetch_assoc(); //ini dari session saat login


//$sql1 = "SELECT * FROM master WHERE Id_KK='$Id_KK'";
$id=$Id_KK["Id_KK"];
//printf($id);
$sql3 = $koneksi->query("SELECT * FROM master WHERE ID_KK='$id'");
$Id_KK=$sql3->fetch_assoc();
$no_kk=$Id_KK["No_KK"];


$sql4 = $koneksi->query("SELECT Username FROM pengguna WHERE Username='$Username'");
$user=$sql4->fetch_assoc(); //ini dari session saat login
$userset=$user["Username"];


// menghitung jumlah data yang ditemukan
$cek = mysqli_num_rows($data);
if($cek > 0){
		$_SESSION['nik'] = $Username;
		$_SESSION['status'] = "login";
		$_SESSION['nama'] = $nama;
		$_SESSION['user2'] = $userset;
		$_SESSION['kk'] = $no_kk;
		header("location: Home.php");
		
	}
else{
	echo 
	"
		<script type='text/javascript'>alert('Username/Password Salah!');
		window.location='Login2.php';

		</script>
	";
	}
?>