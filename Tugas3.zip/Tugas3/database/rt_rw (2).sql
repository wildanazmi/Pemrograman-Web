-- phpMyAdmin SQL Dump
-- version 4.8.2
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Jul 03, 2019 at 02:56 AM
-- Server version: 10.1.34-MariaDB
-- PHP Version: 7.0.31

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `rt_rw`
--

-- --------------------------------------------------------

--
-- Table structure for table `arsip_dinamis`
--

CREATE TABLE `arsip_dinamis` (
  `id` int(10) NOT NULL,
  `no` bigint(20) NOT NULL,
  `tanggal` date NOT NULL,
  `judul` varchar(255) NOT NULL,
  `isi` varchar(255) NOT NULL,
  `link` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `arsip_dinamis`
--

INSERT INTO `arsip_dinamis` (`id`, `no`, `tanggal`, `judul`, `isi`, `link`) VALUES
(13, 291019, '2019-09-07', 'Undangan Makan Bersama ', 'Mengundang seluruh warag RW 01 dan RW 02 untuk hadir dalam acara makan - makan dalam rangka hajatan', 'https://drive.google.com/open?id=1o4y8Fysu0qILlNcyTULjR_DZ5XsbgUFq'),
(14, 291119, '2019-09-07', 'Pemberitahuan Kegiatan Senam Pagi', 'Meminta izin untuk mengadakan senam pagi', 'https://drive.google.com/file/d/1NNowot5Js6SV12ZmL4NV2jAQbdkctYuv/view?usp=sharing');

-- --------------------------------------------------------

--
-- Table structure for table `data_grup`
--

CREATE TABLE `data_grup` (
  `ID` int(11) NOT NULL,
  `ID_Wilayah` int(9) NOT NULL,
  `Id_grup` int(3) NOT NULL,
  `Nama_Group` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `data_grup`
--

INSERT INTO `data_grup` (`ID`, `ID_Wilayah`, `Id_grup`, `Nama_Group`) VALUES
(1, 1, 1, 'RT 01/ RW 01'),
(2, 1, 1, 'RT 01/ RW 01'),
(3, 1, 1, 'RT 01/ RW 01'),
(4, 1, 1, 'RT 01/ RW 01'),
(5, 1, 2, 'RT 02/ RW 01'),
(6, 1, 2, 'RT 02/ RW 01'),
(7, 1, 2, 'RT 02/ RW 01'),
(8, 1, 2, 'RT 02/ RW 01'),
(9, 1, 3, 'RT 03/ RW 01'),
(10, 1, 3, 'RT 03/ RW 01'),
(11, 1, 3, 'RT 03/ RW 01'),
(12, 1, 3, 'RT 03/ RW 01'),
(13, 2, 4, 'RT 01/RW 02'),
(14, 2, 4, 'RT 01/ RW 02'),
(15, 2, 4, 'RT 01/ RW 02'),
(16, 2, 4, 'RT 01/ RW 02'),
(17, 2, 5, 'RT 02/ RW 02'),
(18, 2, 5, 'RT 02/ RW 02'),
(19, 2, 5, 'RT 02/ RW 02'),
(20, 2, 5, 'RT 02/ RW 02'),
(21, 2, 6, 'RT 03/ RW 02'),
(22, 2, 6, 'RT 03/ RW 02'),
(23, 2, 6, 'RT 03/ RW 02'),
(24, 2, 6, 'RT 03/ RW 02');

-- --------------------------------------------------------

--
-- Table structure for table `detail_kk`
--

CREATE TABLE `detail_kk` (
  `ID_detail` int(11) NOT NULL,
  `Id_KK` int(11) NOT NULL,
  `NIK` bigint(20) NOT NULL,
  `nama_anggota` varchar(20) NOT NULL,
  `status_anggota` varchar(15) NOT NULL,
  `ttl` date NOT NULL,
  `nama_ibu` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `detail_kk`
--

INSERT INTO `detail_kk` (`ID_detail`, `Id_KK`, `NIK`, `nama_anggota`, `status_anggota`, `ttl`, `nama_ibu`) VALUES
(1, 1, 33273400000, 'Mulyono', 'Kepala Keluarga', '1988-10-29', 'Sumiyati'),
(2, 1, 33271600000, 'Eni', 'Istri', '1990-05-20', 'Syubaidah'),
(3, 2, 33270200000, 'Agus', 'Kepala Keluarga', '1978-06-19', 'Baini'),
(4, 2, 33272900000, 'Lisa', 'Istri', '1978-07-12', 'Barkah\r\n'),
(5, 2, 33272100000, 'Hanan', 'Anak', '1999-05-15', 'Lisa'),
(6, 3, 33271300000, 'Budi', 'Kepala Keluarga', '1980-03-12', 'Muinah'),
(7, 3, 33271400000, 'Bunaya', 'Istri', '1982-06-17', 'Mukawi'),
(8, 4, 33274300000, 'Sugiharto', 'Kepala Keluarga', '1970-10-28', 'Nur Afiyah'),
(9, 5, 33273000000, 'Mahzun', 'Kepala Keluarga', '1978-10-27', 'Hasna'),
(10, 5, 33272300000, 'Ira', 'Istri', '1980-07-10', 'Sikadoy'),
(11, 5, 33271700000, 'Esti', 'Anak', '2000-08-12', 'Ira Jelita'),
(12, 6, 33274500000, 'Syaban', 'Kepala Keluarga', '1980-10-10', 'Barokah'),
(13, 7, 33274600000, 'Syahroni', 'Kepala Keluarga', '1970-12-12', 'Dewinta'),
(14, 7, 33274400000, 'Suinah', 'Istri', '1988-10-19', 'Mabnunah'),
(15, 8, 33270700000, 'Aziz', 'Kepala Keluarga', '1990-12-10', 'Aniah'),
(16, 8, 33274100000, 'Salsabila', 'Istri', '1990-10-08', 'Aulia'),
(17, 9, 33273900000, 'Rafi', 'Kepala Keluarga', '1990-05-24', 'Reni'),
(18, 9, 33273600000, 'Nagita', 'Istri', '1990-10-19', 'Slavina'),
(19, 10, 33271200000, 'Bonaparte', 'Kepala Keluarga', '1978-10-20', 'Sukeni'),
(20, 10, 33273700000, 'Najwa', 'Istri', '1978-08-08', 'Shihab'),
(21, 11, 33272500000, 'Jack', 'Kepala Keluarga', '1970-10-10', 'Jacklin'),
(22, 11, 33273100000, 'Maimunah', 'Istri', '1976-10-05', 'Marsinah'),
(23, 12, 33274800000, 'Yusup', 'Kepala Keluarga', '1997-06-05', 'Saikinah'),
(24, 12, 33274200000, 'Sinok', 'Istri', '1998-10-08', 'Noknar'),
(25, 13, 33270900000, 'Basuki', 'Kepala Keluarga', '1967-10-29', 'Basnari'),
(26, 13, 33272800000, 'Linain', 'Istri', '1970-08-16', 'Aini'),
(27, 13, 33270300000, 'Ahok', 'Anak', '2006-07-08', 'Linain'),
(28, 14, 33272600000, 'Joko', 'Kepala Keluarga', '1980-06-10', 'Sutiyem'),
(29, 15, 33272700000, 'Limbad', 'Kepala Keluarga', '1987-09-09', 'Limbani'),
(30, 15, 33272400000, 'Isnaini', 'Istri', '1990-06-10', 'Isnur'),
(31, 16, 33270800000, 'Baharudin', 'Kepala Keluarga', '1990-05-12', 'Banuraini'),
(32, 16, 33270100000, 'Afiyha', 'Istri', '1992-08-12', 'Bundani'),
(33, 17, 33271000000, 'Bejo', 'Kepala Keluarga', '1969-10-10', 'Bela'),
(34, 17, 33271100000, 'Beni', 'Istri', '1970-10-02', 'Baini Aila'),
(35, 18, 33271800000, 'Fatah', 'Kepala Keluarga', '1980-06-11', 'Kusnaeni'),
(36, 18, 33271500000, 'Emi', 'Istri', '1980-10-18', 'Junaeni'),
(37, 19, 33270400000, 'Ali', 'Kepala Keluarga', '1990-05-22', 'Emili'),
(38, 19, 33273500000, 'Musifa', 'Istri', '1990-10-12', 'Musdalifah'),
(39, 20, 33271900000, 'Fatih', 'Kepala Keluarga', '1990-05-18', 'Alimi'),
(40, 20, 33272000000, 'Fatihah', 'Istri', '1992-09-10', 'Daenur'),
(41, 21, 33270600000, 'Andi', 'Kepala Keluarga', '1980-06-14', 'Nadine'),
(42, 21, 33270500000, 'Alifia', 'Istri', '1980-10-14', 'Musfaedah'),
(43, 22, 33273200000, 'Maman', 'Kepala Keluarga', '1990-05-23', 'Mandrani'),
(44, 22, 33273300000, 'Masturi', 'Istri', '1991-10-01', 'Masauni'),
(45, 23, 33274700000, 'Viko', 'Kepala Keluarga', '1970-10-08', 'Virda'),
(46, 23, 33273800000, 'Nurahmah', 'Istri', '1980-10-13', 'Nuslihah'),
(47, 23, 33274900000, 'Bunya', 'Anak', '2009-10-10', 'Nurahmah'),
(48, 24, 33272200000, 'Iqbal', 'Kepala Keluarga', '1996-10-10', 'Istiqomah'),
(49, 24, 33274000000, 'Risma ', 'Istri', '1997-09-10', 'Maulina');

-- --------------------------------------------------------

--
-- Table structure for table `list_rtrw`
--

CREATE TABLE `list_rtrw` (
  `ID` int(3) NOT NULL,
  `nama_kepala_keluarga` varchar(100) NOT NULL,
  `alamat` varchar(200) NOT NULL,
  `jumlah_anggota_keluarga` int(2) NOT NULL,
  `RT` int(2) NOT NULL,
  `RW` int(2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `list_rtrw`
--

INSERT INTO `list_rtrw` (`ID`, `nama_kepala_keluarga`, `alamat`, `jumlah_anggota_keluarga`, `RT`, `RW`) VALUES
(1, 'Mulyono', 'Jalan Perwira no 1, RT 01/ RW 01, Surakarta', 2, 1, 1),
(2, 'Agus', 'Jalan Perwira no 2 , RT 01 / RW 01 , Surakarta', 5, 1, 1),
(3, 'Budi', 'Jalan Perwira no 3 , RT 01 / RW 01, Surakarta', 3, 1, 1),
(4, 'Sugiharto', 'Jalan Perwira no 4, RT 01/ RW 01, Surakarta', 3, 1, 1),
(5, 'Sujai', 'Jalan Perwira no 5, RT 01/ RW 01, Surakarta', 6, 1, 1),
(6, 'Afrima', 'Jalan Perwira no 6, RT 01/ RW 01, Surakarta', 2, 1, 1),
(7, 'Wildan', 'Jalan Perwira no 7, RT 01/ RW 01, Surakarta', 3, 1, 1),
(8, 'Fiqi Azmi', 'Jalan Perwira no 8, RT 01/ RW 01, Surakarta', 3, 1, 1),
(9, 'Mahas Mig', 'Jalan Perwira no 9, RT 01/ RW 01, Surakarta', 2, 1, 1),
(10, 'Zainul Marufin', 'Jalan Perwira no 10, RT 01/ RW 01, Surakarta', 4, 1, 1),
(11, 'Mahzun Marzuki', 'Jalan Anggrek no 1, RT 02/ RW 01, Surakarta', 3, 2, 1),
(12, 'Syaban', 'Jalan Anggrek no 2, RT 02/ RW 01, Surakarta', 5, 2, 1),
(13, 'Syahroni Abdul', 'Jalan Anggrek no 3, RT 02/ RW 01, Surakarta', 2, 2, 1),
(14, 'Aziz Rifai', 'Jalan Anggrek no 4, RT 02/ RW 01, Surakarta', 4, 2, 1),
(15, 'Syarifudin', 'Jalan Anggrek no 5, RT 02/ RW 01, Surakarta', 3, 2, 1),
(16, 'Ahmad Dani', 'Jalan Anggrek no 6, RT 02/ RW 01, Surakarta', 7, 2, 1),
(17, 'Muhammad Sabil', 'Jalan Anggrek no 7, RT 02/ RW 01, Surakarta', 9, 2, 1),
(18, 'Mahromi', 'Jalan Anggrek no 8, RT 02/ RW 01, Surakarta', 4, 2, 1),
(19, 'Hamdani', 'Jalan Anggrek no 9, RT 02/ RW 01, Surakarta', 5, 2, 1),
(20, 'Marufin Ilham', 'Jalan Anggrek no 10, RT 02/ RW 01, Surakarta', 5, 2, 1),
(21, 'Rafi Ahmad', 'Jalan Mawar no 1, RT 03/ RW 01, Surakarta ', 3, 3, 1),
(22, 'Bonaparte', 'Jalan Mawar no 2, RT 03/ RW 01, Surakarta ', 5, 3, 1),
(23, 'Jack Ma', 'Jalan Mawar no 3, RT 03/ RW 01, Surakarta ', 6, 3, 1),
(24, 'Yusup', 'Jalan Mawar no 4, RT 03/ RW 01, Surakarta ', 3, 3, 1),
(25, 'Basuki', 'Jalan Rosalia no 1, RT 01/ RW 02, Surakarta', 6, 1, 2),
(26, 'Joko Purnomo', 'Jalan Rosalia no 2, RT 01/ RW 02, Surakarta', 2, 1, 2),
(27, 'Limbad', 'Jalan Rosalia no 3, RT 01/ RW 02, Surakarta', 4, 1, 2),
(28, 'Baharudin', 'Jalan Rosalia no 4, RT 01/ RW 02, Surakarta', 5, 1, 2),
(29, 'Bejo', 'Jalan Tulip no 1 , RT 02 / RW 02 , Surakarta', 4, 2, 2),
(30, 'Fatah', 'Jalan Tulip no 2 , RT 02 / RW 02 , Surakarta', 4, 2, 2),
(31, 'Ali', 'Jalan Tulip no 3 , RT 02 / RW 02 , Surakarta', 3, 2, 2),
(32, 'Fatih', 'Jalan Tulip no 4 , RT 02 / RW 02 , Surakarta', 4, 2, 2),
(33, 'Andi', 'Jalan Melati no 1 , RT 03 / RW 02 , Surakarta', 3, 3, 2),
(34, 'Maman', 'Jalan Melati no 2 , RT 03 / RW 02 , Surakarta', 2, 3, 2),
(35, 'Viko', 'Jalan Melati no 3 , RT 03 / RW 02 , Surakarta', 9, 3, 2),
(36, 'Iqbal', 'Jalan Melati no 4 , RT 03 / RW 02 , Surakarta', 3, 3, 2);

-- --------------------------------------------------------

--
-- Table structure for table `master`
--

CREATE TABLE `master` (
  `ID_KK` int(12) NOT NULL,
  `No_KK` bigint(11) NOT NULL,
  `kepala_klg` varchar(20) NOT NULL,
  `alamat` varchar(100) NOT NULL,
  `rt` int(3) NOT NULL,
  `rw` int(3) NOT NULL,
  `Id_wilayah` int(9) NOT NULL,
  `Id_grup` int(12) NOT NULL,
  `status_kk` varchar(30) NOT NULL,
  `jumlah_anggota` int(2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `master`
--

INSERT INTO `master` (`ID_KK`, `No_KK`, `kepala_klg`, `alamat`, `rt`, `rw`, `Id_wilayah`, `Id_grup`, `status_kk`, `jumlah_anggota`) VALUES
(1, 33270000001, 'Mulyono', 'Jalan Perwira no 1, RT 01/ RW 01, Surakarta\r\n', 1, 1, 1, 1, 'Aktif', 2),
(2, 33270000002, 'Agus', 'Jalan Perwira no 2, RT 01/ RW 01, Surakarta\r\n', 1, 1, 1, 1, 'Aktif', 3),
(3, 33270000003, 'Budi', 'Jalan Perwira no 3, RT 01/ RW 01, Surakarta\r\n', 1, 1, 1, 1, 'Aktif', 2),
(4, 33270000004, 'Sugiharto', 'Jalan Perwira no 4, RT 01/ RW 01, Surakarta', 1, 1, 1, 1, 'Aktif', 1),
(5, 33270000005, 'Mahzun', 'Jalan Anggrek no 1, RT 02/ RW 01, Surakarta\r\n', 2, 1, 1, 2, 'Aktif', 3),
(6, 33270000006, 'Syaban', 'Jalan Anggrek no 2, RT 02/ RW 01, Surakarta\r\n', 2, 1, 1, 2, 'Aktif', 1),
(7, 33270000007, 'Syahroni', 'Jalan Anggrek no 3, RT 02/ RW 01, Surakarta\r\n', 2, 1, 1, 2, 'Aktif', 2),
(8, 33270000008, 'Aziz', 'Jalan Anggrek no 4, RT 02/ RW 01, Surakarta', 2, 1, 1, 2, 'Aktif', 2),
(9, 33270000009, 'Rafi', 'Jalan Mawar no 1, RT 03/ RW 01, Surakarta\r\n', 3, 1, 1, 3, 'Aktif', 2),
(10, 33270000010, 'Bonaparte', 'Jalan Mawar no 2, RT 03/ RW 01, Surakarta', 3, 1, 1, 3, 'Aktif', 2),
(11, 33270000011, 'Jack', 'Jalan Mawar no 3, RT 03/ RW 01, Surakarta', 3, 1, 1, 3, 'Aktif', 2),
(12, 33270000012, 'Yusup', 'Jalan Mawar no 4, RT 03/ RW 01, Surakarta', 3, 1, 1, 3, 'Aktif', 2),
(13, 33270000013, 'Basuki', 'Jalan Rosalia no 1, RT 01/ RW 02, Surakarta\r\n', 1, 2, 2, 4, 'Aktif', 3),
(14, 33270000014, 'Joko', 'Jalan Rosalia no 2, RT 01/ RW 02, Surakarta\r\n', 1, 2, 2, 4, 'Aktif', 1),
(15, 33270000015, 'Limbad', 'Jalan Rosalia no 3, RT 01/ RW 02, Surakarta', 1, 2, 2, 4, 'Aktif', 2),
(16, 33270000016, 'Baharudin', 'Jalan Rosalia no 4, RT 01/ RW 02, Surakarta', 1, 2, 2, 4, 'Aktif', 2),
(17, 33270000017, 'Bejo', 'Jalan Tulip no 1 , RT 02 / RW 02 , Surakarta', 2, 2, 2, 5, 'Aktif', 2),
(18, 33270000018, 'Fatah', 'Jalan Tulip no 2 , RT 02 / RW 02 , Surakarta', 2, 2, 2, 5, 'Aktif', 2),
(19, 33270000019, 'Ali', 'Jalan Tulip no 3 , RT 02 / RW 02 , Surakarta', 2, 2, 2, 5, 'Proses Mutasi', 2),
(20, 33270000020, 'Fatih', 'Jalan Tulip no 4 , RT 02 / RW 02 , Surakarta', 2, 2, 2, 5, 'Aktif', 2),
(21, 33270000021, 'Andi', 'Jalan Melati no 1 , RT 03 / RW 02 , Surakarta', 3, 2, 2, 6, 'Aktif', 2),
(22, 33270000021, 'Maman', 'Jalan Melati no 2 , RT 03 / RW 02 , Surakarta', 3, 2, 2, 6, 'Proses Mutasi', 2),
(23, 33270000023, 'Viko', 'Jalan Melati no 3 , RT 03 / RW 02 , Surakarta', 3, 2, 2, 6, 'Aktif', 3),
(24, 33270000024, 'Iqbal', 'Jalan Melati no 4 , RT 03 / RW 02 , Surakarta', 3, 2, 2, 6, 'Aktif', 2);

-- --------------------------------------------------------

--
-- Table structure for table `mutasi`
--

CREATE TABLE `mutasi` (
  `ID` int(11) NOT NULL,
  `ID_KK` int(11) NOT NULL,
  `tanggal` date NOT NULL,
  `ID_lama` int(11) NOT NULL,
  `ID_baru` varchar(11) NOT NULL,
  `approval` varchar(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `mutasi`
--

INSERT INTO `mutasi` (`ID`, `ID_KK`, `tanggal`, `ID_lama`, `ID_baru`, `approval`) VALUES
(1, 19, '2019-07-02', 19, '-', 'Proses'),
(2, 22, '2019-07-03', 22, '-', 'Proses');

-- --------------------------------------------------------

--
-- Table structure for table `pengguna`
--

CREATE TABLE `pengguna` (
  `ID` int(11) NOT NULL,
  `Username` bigint(20) NOT NULL,
  `Nama` varchar(100) NOT NULL,
  `Password` varchar(100) NOT NULL,
  `ID_Group` int(12) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `pengguna`
--

INSERT INTO `pengguna` (`ID`, `Username`, `Nama`, `Password`, `ID_Group`) VALUES
(32, 33270100000, 'Afiyha', '1111', 4),
(3, 33270200000, 'Agus', '1111', 1),
(27, 33270300000, 'Ahok', '1234', 4),
(37, 33270400000, 'Ali', '1234', 5),
(42, 33270500000, 'Alifia', '1234', 6),
(41, 33270600000, 'Andi', '1234', 6),
(15, 33270700000, 'Aziz', '1234', 2),
(31, 33270800000, 'Baharudin', '1234', 4),
(25, 33270900000, 'Basuki', '1234', 4),
(33, 33271000000, 'Bejo', '1234', 5),
(34, 33271100000, 'Beni', '1234', 5),
(19, 33271200000, 'Bonaparte', '1234', 3),
(6, 33271300000, 'Budi', '1234', 1),
(7, 33271400000, 'Bunaya', '1234', 1),
(36, 33271500000, 'Emi', '1234', 5),
(2, 33271600000, 'Eni', '1234', 1),
(11, 33271700000, 'Esti', '1234', 2),
(35, 33271800000, 'Fatah', '1234', 5),
(39, 33271900000, 'Fatih', '1234', 5),
(40, 33272000000, 'Fatihah', '1234', 5),
(5, 33272100000, 'Hanan', '1234', 1),
(48, 33272200000, 'Iqbal', '1234', 6),
(10, 33272300000, 'Ira', '1234', 2),
(30, 33272400000, 'Isnaini', '1234', 4),
(21, 33272500000, 'Jack', '1234', 3),
(28, 33272600000, 'Joko', '1234', 4),
(29, 33272700000, 'Limbad', '1234', 4),
(26, 33272800000, 'Linain', '1234', 4),
(4, 33272900000, 'Lisa', '1234', 1),
(9, 33273000000, 'Mahzun', '1234', 2),
(22, 33273100000, 'Maimunah', '1234', 3),
(43, 33273200000, 'Maman', '1234', 6),
(44, 33273300000, 'Masturi', '1234', 6),
(1, 33273400000, 'Mulyono', '1234', 1),
(38, 33273500000, 'Musifa', '1234', 5),
(18, 33273600000, 'Nagita', '1234', 3),
(20, 33273700000, 'Najwa', '1234', 3),
(46, 33273800000, 'Nurahmah', '1234', 6),
(17, 33273900000, 'Rafi', '1234', 3),
(49, 33274000000, 'Risma', '1234', 6),
(16, 33274100000, 'Salsabila', '1234', 2),
(24, 33274200000, 'Sinok', '1234', 3),
(8, 33274300000, 'Sugiharto', '1234', 1),
(14, 33274400000, 'Suinah', '1234', 2),
(12, 33274500000, 'Syaban', '1234', 2),
(13, 33274600000, 'Syahroni', '1234', 2),
(45, 33274700000, 'Viko', '1234', 6),
(23, 33274800000, 'Yusup', '1234', 3),
(47, 33274900000, 'Bunya', '1234', 6);

-- --------------------------------------------------------

--
-- Table structure for table `Tagihan`
--

CREATE TABLE `Tagihan` (
  `ID_Tagihan` int(20) NOT NULL,
  `ID_KK` int(20) NOT NULL,
  `No_KK` bigint(20) NOT NULL,
  `Nama_Kepala_Kel` varchar(100) NOT NULL,
  `Jumlah_tagihan` int(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Tagihan`
--

INSERT INTO `Tagihan` (`ID_Tagihan`, `ID_KK`, `No_KK`, `Nama_Kepala_Kel`, `Jumlah_tagihan`) VALUES
(1, 1, 33270000001, 'Mulyono', 100000),
(2, 2, 33270000002, 'Agus', 200000),
(3, 3, 33270000003, 'Budi', 120000),
(4, 4, 33270000004, 'Sugiharto', 50000),
(5, 5, 33270000005, 'Mahzun', 90000),
(6, 6, 33270000006, 'Syaban', 178000),
(7, 7, 33270000007, 'Syahroni', 190000),
(8, 8, 33270000008, 'Aziz', 156000),
(9, 9, 33270000009, 'Rafi', 60000),
(10, 10, 33270000010, 'Bonaparte', 145000),
(11, 11, 33270000011, 'Jack', 15000),
(12, 12, 33270000012, 'Yusup', 98000),
(13, 13, 33270000013, 'Basuki', 149000),
(14, 14, 33270000014, 'Joko', 10000),
(15, 15, 33270000015, 'Limbad', 0),
(16, 16, 33270000016, 'Baharudin', 1900),
(17, 17, 33270000017, 'Bejo', 76000),
(18, 18, 33270000018, 'Fatah', 0),
(19, 19, 33270000019, 'Ali', 187000),
(20, 20, 33270000020, 'Fatih', 0),
(21, 21, 33270000021, 'Andi', 13500),
(22, 22, 33270000022, 'Maman', 16000),
(23, 23, 33270000023, 'Viko', 120000),
(24, 24, 33270000024, 'Iqbal', 0);

-- --------------------------------------------------------

--
-- Table structure for table `upload`
--

CREATE TABLE `upload` (
  `id_file` int(11) NOT NULL,
  `ID_Tagihan` int(20) NOT NULL,
  `nama_file` varchar(100) NOT NULL,
  `tanggal` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `nominal` bigint(20) NOT NULL,
  `bukti` varchar(245) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `upload`
--

INSERT INTO `upload` (`id_file`, `ID_Tagihan`, `nama_file`, `tanggal`, `nominal`, `bukti`) VALUES
(203, 16, '', '2019-07-03 00:51:33', 100, ''),
(204, 16, 'buka12.png', '2019-07-03 00:53:58', 100, '/Applications/XAMPP/xamppfiles/temp/phpLyRjX0'),
(201, 16, '', '2019-07-03 00:08:01', 100, ''),
(202, 16, '', '2019-07-03 00:51:24', 100, '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `arsip_dinamis`
--
ALTER TABLE `arsip_dinamis`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `data_grup`
--
ALTER TABLE `data_grup`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `detail_kk`
--
ALTER TABLE `detail_kk`
  ADD PRIMARY KEY (`ID_detail`);

--
-- Indexes for table `list_rtrw`
--
ALTER TABLE `list_rtrw`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `master`
--
ALTER TABLE `master`
  ADD PRIMARY KEY (`ID_KK`);

--
-- Indexes for table `mutasi`
--
ALTER TABLE `mutasi`
  ADD PRIMARY KEY (`ID_KK`);

--
-- Indexes for table `pengguna`
--
ALTER TABLE `pengguna`
  ADD PRIMARY KEY (`Username`);

--
-- Indexes for table `Tagihan`
--
ALTER TABLE `Tagihan`
  ADD PRIMARY KEY (`ID_Tagihan`);

--
-- Indexes for table `upload`
--
ALTER TABLE `upload`
  ADD PRIMARY KEY (`id_file`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `arsip_dinamis`
--
ALTER TABLE `arsip_dinamis`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `list_rtrw`
--
ALTER TABLE `list_rtrw`
  MODIFY `ID` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=37;

--
-- AUTO_INCREMENT for table `Tagihan`
--
ALTER TABLE `Tagihan`
  MODIFY `ID_Tagihan` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT for table `upload`
--
ALTER TABLE `upload`
  MODIFY `id_file` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=205;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
