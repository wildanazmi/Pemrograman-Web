	<?php
	session_start();
	include 'koneksi.php';

 
// menangkap data yang dikirim dari form
		
 
	//mengatasi error notice dan warning
	//error ini biasa muncul jika dijalankan di localhost, jika online tidak ada masalah
	error_reporting(E_ALL ^ (E_NOTICE | E_WARNING));
	
	//koneksi ke database

	
	
	//proses jika tombol rubah di klik
	if($_POST['submit']){
		//membuat variabel untuk menyimpan data inputan yang di isikan di form
		$password_lama			= $_POST['password_lama'];
		$password_baru			= $_POST['password_baru'];
		$konfirmasi_password	= $_POST['konfirmasi_password'];
		
		//cek dahulu ke database dengan query SELECT
		//kondisi adalah WHERE (dimana) kolom password adalah $password_lama di encrypt m5
		//encrypt -> md5($password_lama)
		$password_lama	= ($password_lama);
		$cek 			= $koneksi->query("SELECT Password FROM pengguna WHERE Password='$password_lama'");
		if($cek->num_rows){
			//kondisi ini jika password lama yang dimasukkan sama dengan yang ada di database
			//membuat kondisi minimal password adalah 5 karakter
			if(strlen($password_baru) >= 4){
				//jika password baru sudah 5 atau lebih, maka lanjut ke bawah
				//membuat kondisi jika password baru harus sama dengan konfirmasi password
				if($password_baru == $konfirmasi_password){
					//jika semua kondisi sudah benar, maka melakukan update kedatabase
					//query UPDATE SET password = encrypt md5 password_baru
					//kondisi WHERE id user = session id pada saat login, maka yang di ubah hanya user dengan id tersebut
				$password_baru 	= ($password_baru);
				$username 		= $_SESSION['user2']; //ini dari session saat login
				$update 		= $koneksi->query("UPDATE pengguna SET Password='$password_baru' WHERE Username='$username'");
					if($update){
						//kondisi jika proses query UPDATE berhasil
						echo "<script type='text/javascript'>alert('Password Berhasil Diubah!');
						window.location='Home.php';</script>";
						}
						else{
						//kondisi jika proses query gagal
						echo "<script type='text/javascript'>alert('Password gagal Diubah!');
						window.location='Home.php';</script>";
						}					
				}else{
					//kondisi jika password baru beda dengan konfirmasi password
					echo "<script type='text/javascript'>alert('Konfirmasi Password Salah!');
						window.location='Home.php';</script>";
						}
			}else{
				//kondisi jika password baru yang dimasukkan kurang dari 5 karakter
				 echo "<script type='text/javascript'>alert('Password Minimal 4 Karakter!');
						window.location='Home.php';</script>";
						}
		}else{
			//kondisi jika password lama tidak cocok dengan data yang ada di database
			 echo "<script type='text/javascript'>alert('Password Lama Tidak Cocok!');
						window.location='Home.php';</script>";
						}
	}
	?>
	