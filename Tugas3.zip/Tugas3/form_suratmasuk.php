<?php 
session_start();
$nik = $_SESSION['nik'];
$kk = $_SESSION['kk'];
?><!doctype html>
<html>
<head>
<meta charset="utf-8">
<title> Tagihan </title>

<style type= "text/css">
h1{
	text-align: center;
	padding-top: 50px;
	font-size: 30px;}

table {
	padding-top: 30px;
	width: 80%;
	align: center;
	font-family: monospace;
	font-size: 20px;
	text-align: center;
	margin: auto;}
	
th {
	background-color: #707272;
	color: white;
	padding-top: 10px;
	padding-bottom: 10px;
	padding-left: 30px;
	padding-right: 30px;} 

td {
	padding-left: 30px;
	padding-right: 30px;
	padding-top: 10px;
	padding-bottom: 10px;
	color: black;}
form {
	left: 520px;
	padding: 5px;
	position: relative;
	font-size: 50px;
}
form > h3 {
	padding: 5px;
	position: absolute;
	font-size: 15px;
}
.para {
	padding-left: 580px;
	font-size: 20px;
	padding-top: 0px;
}
.link {
	text-align: center;
	padding-top: 50px;
	padding-bottom: 0px;

}
	
</style>
<link rel="stylesheet" type="text/css" href="css/style.css">
</head>

<body>

		<div class="main">
			<ul>
				<li><a href="Home.php">Home</a></li>
				<li><a href="List.php">List RT / RW</a></li>
				<li><a href="keluarga.php">Lihat Data Keluarga</a></li>
				<li><a href="arsip.php">Arsip</a></li>
				<li><a href="Iuran.php">Tagihan Iuran</a></li>
				<li><a href="login2.php">Logout</a>
				<li><a href="settingpass.php">Akun</a></li>
			</ul>
		</div>
		
	<h1>Form Anda Telah Dikirim dan Menunggu Konfirmasi Admin! </h1><br>
	<h1>Silahkan Cek di Lihar Arsip</h1>
	<div class="link">
	<?php
		include 'koneksi.php';
		if($_POST['arsip_dinamis']){
			$nomor = $_POST['nomor'];
			$judul = $_POST['judul'];
			$isi = $_POST['isi'];
			$link = $_POST['link'];
			$tanggal = $_POST['tanggal'];
			//printf($judul);
				//input data pembayaran
					//$query = "INSERT INTO `arsip_dinamis` (`id`,`tangal`,`judul`,`isi`) VALUES (null,null,'$judul','$isi')";
					//$ins = $koneksi->query($query);
				mysqli_query($koneksi,"INSERT INTO arsip_dinamis values(null,'$nomor','$tanggal','$judul','$isi','$link')");

				
				//update data tagihan
					//$sisa = $_POST['tagihan']-$jmlh;
					//$query1 = "INSERT `arsip_dinamis` SET `Jumlah_tagihan`='$sisa' WHERE ID_Tagihan = '$id_tagihan'";
					//$update=$koneksi->query($query1);
		}
		?>
		</div>

		<br/>
		<br/>
		<a class="para" href="surat_masuk.php">Buat Lagi</a>
		<br/>
		<br/>
	</body>
</html>