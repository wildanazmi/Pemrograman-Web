<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title> Form Surat </title>

<style type= "text/css">
h1{
	text-align: center;
	padding-top: 50px;
	font-size: 30px;}


.list {
	font-size: 20px;
}
.surform {
	padding-left: 200px;
	padding-top: 50px;

}
input {
		width: 80%;
		height: 50px;
		box-sizing: border-box;
}
.submit {
	width: 20%;
}
</style>
<link rel="stylesheet" type="text/css" href="css/style.css">
</head>

<body>

		<div class="main">
			<ul>
				<li><a href="Home.php">Home</a></li>
				<li><a href="List.php">List RT / RW</a></li>
				<li><a href="keluarga.php">Lihat Data Keluarga</a></li>
				<li><a href="arsip.php">Arsip</a></li>
				<li><a href="Iuran.php">Tagihan Iuran</a></li>
				<li><a href="mutasi.php">Mutasi</a></li>
				<li><a href="login2.php">Logout</a>
				<li><a href="settingpass.php">Akun</a></li>	
			</ul>
		</div>
		<h1> Isi Form</h1>

<div class="surform">
		
<form action="form_suratmasuk.php" method="post" enctype="multipart/form-data">
  	Nomor Surat:<br><br>
  	<input type="text" name="nomor"><br><br>
  	Tanggal Surat:<br><br>
  	<input type="date" name="tanggal"><br><br>
  	Judul:<br><br>
  	<input type="text" name="judul"><br><br>
  	Isi:<br><br>
  	<input type="text" name="isi"><br><br>
  	Link:<br><br>
  	<input type="text" name="link"><br><br>
  	<input class="submit" type="submit" name="arsip_dinamis" value="Submit">
</form>
</div>
	</body>
	</html>
