<!doctype html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>

<title> Arsip </title>

<style type= "text/css">

.list {
	font-size: 20px;
}
h1{
	text-align: center;
	padding-top: 50px;
	font-size: 30px;}

.table-hover{
	width: 90%;
	margin: 0 auto;
	font-family: verdana;
}
body, .main, ul, li, td{

	font-family: verdana;
}
</style>
<link rel="stylesheet" type="text/css" href="css/style.css">
</head>

<body>

		<div class="main">
			<ul>
				<li><a href="Home.php">Home</a></li>
				<li><a href="List.php">List RT / RW</a></li>
				<li><a href="keluarga.php">Lihat Data Keluarga</a></li>
				<li><a href="arsip.php">Arsip</a></li>
				<li><a href="Iuran.php">Tagihan Iuran</a></li>
				<li><a href="mutasi.php">Mutasi</a></li>
				<li><a href="login2.php">Logout</a>
				<li><a href="settingpass.php">Akun</a></li>
			</ul>
		</div>

		<h1> Lihat Arsip </h1>
<table> 
	<table class="table table-hover">
  <thead>
    <tr>
      <th scope="col">Tanggal Surat</th>
      <th scope="col">Judul Surat</th>
      <th scope="col">Isi Surat</th>
      <th scope="col">Link Download</th>
    </tr>
  </thead>
  <tbody>
   </tbody>

	<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "rt_rw";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

$sql = $conn->query("SELECT * FROM arsip_dinamis");
	while($row = $sql->fetch_assoc()){
				echo "<tr>
				<td>" . $row["tanggal"]. " </td>
				<td>" . $row["judul"]. " </td>
				<td>" . $row["isi"]. " </td>	
				<td>" . $row["link"]."</td>		
				</tr>";

	}
//if ($result->num_rows > 0) {
    // output data of each row
//    while($row = $result->fetch_assoc()) {
//	}
//} else {
	//printf($nama);
	//print($sql);
    //echo "0 results";
//}
//}
$conn->close();
?>
</table>
	
</body>
</html>