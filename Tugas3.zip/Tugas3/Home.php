<?php 
session_start();
$user = $_SESSION['user2']; //ini dari session saat login
$name = $_SESSION['nama'];
if($_SESSION['status']!="login"){
	header("location:login2.php");

}

?>



<!doctype html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>

	<title>Website Tugas</title>
	<link rel="stylesheet" type="text/css" href="css/style.css">
</head>

<body>
	<nav>
		<div class="main">
			<ul>
				<li><a href="Home.php">Home</a></li>
				<li><a href="List.php">List RT / RW</a></li>
				<li><a href="Keluarga.php">Lihat Data Keluarga</a></li>
				<li><a href="arsip.php">Arsip</a></li>
				<li><a href="Iuran.php">Tagihan Iuran</a></li>
				<li><a href="mutasi.php">Mutasi</a></li>
				<li><a href="login2.php">Logout</a></li>
				<li><a href="settingpass.php">Akun</a></li>
			</ul>
		</div>
		<div class="title">
			<h1>Selamat Datang 
				<?php
				echo $name;
				?> di</h1>
			<h1>Aplikasi RT / RW Online</h1>
		</div>
	</nav>
	
	<div class="home">
		<h2>Tujuan</h2>
		<p>Aplikasi RT/RW Online adalah aplikasi yang bertujuan untuk membantu mempermudah tugas-tugas  Pengurus Rumah Tangga (RT) dalam menata administrasi warga maupun keuangan sehingga menjadi lebih transparan. Juga membantu warga dalam proses pencarian informasi dalam lingkup RT / RW.
		</p><br><p><strong>-------------</strong></p><br>
	
		
		<h2>Fitur</h2>
		<h3>1. Informasi Warga</h3>
		<p>Fitur ini merupakan fasilias untuk mendapatkan informasi - informasi yang sangat berguna dan bermanfaat baik bagi warga, pengurus RT maupun bagi pihak-pihak lain yang membutuhkan. Informasi dapat diakses secara mudah setiap saat dan kapanpun dan dimanapun anda berada. Selain itu juga berfungsi untuk pengelolaan data dan penyajian informasi yang terkait dengan warga, mulai dari kelahiran,  warga pindah alamat, kematian, serta fasilitas-fasilitas lain yang dapat diakses langsung oleh warga.</p>
		
		<h3>2. Keuangan</h3>
		<p>Fitur ini berfungsi untuk mempermudah dan mempercepat proses pencatatan dan pengelolaan iuran yang dikelola oleh Pengurus RT, sehingga tata kelola administrasi keuangan RT akan lebih tertib, transparan dan tertata dengan baik.</p>
		
		<h3>3. Arsip</h3>
		<p>Fitur ini berfungsi untuk mempermudah proses administrasi surat menyurat baik masuk ataupun keluar dalam lingkup RT / RW</p><br><br><br>
	</div>	
		

<script src="js/main.js"></script>

<div class="footer">
  	<p>Contact US : +62 85601754527</p>
</div>
	</div>
</body>
</html>
