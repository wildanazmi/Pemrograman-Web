<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Daftar RT 03/ RW 01</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
<style type= "text/css">
h1{
	text-align: center;
	padding-top: 50px;
	font-size: 30px;}

.table-hover{
	width: 90%;
	margin: 0 auto;
	font-family: verdana;
}
body, .main, ul, li, td{

	font-family: verdana;
}
	
</style>
<link rel="stylesheet" type="text/css" href="css/style.css">
</head>

<body>

		<div class="main">
			<ul>
				<li><a href="Home.php">Home</a></li>
				<li><a href="List.php">List RT / RW</a></li>
				<li><a href="Keluarga.php">Lihat Data Keluarga</a></li>
				<li><a href="arsip.php">Arsip</a></li>
				<li><a href="Iuran.php">Tagihan Iuran</a></li>
				<li><a href="mutasi.php">Mutasi</a></li>
				<li><a href="login2.php">Logout</a></li>
				<li><a href="settingpass.php">Akun</a></li>		
			</ul>
		</div>
		
		<h1> Daftar Warga RT 03/ RW 01</h1>
		
<table> 
	 
<table class="table table-hover">
  <thead>
    <tr>
      <th scope="col">Nama Kepala Keluarga</th>
      <th scope="col">Alamat</th>
      <th scope="col">Jumlah Anggota</th>
      <th scope="col">Status KK</th>
    </tr>
  </thead>
  <tbody>
   </tbody>
	<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "rt_rw";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

$sql = "SELECT * FROM master WHERE  rt = 3 AND rw = 1";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
    	echo "<tr>
				<td>" . $row["kepala_klg"]. "</td>
				<td>" . $row["alamat"]. " </td>
				<td>" . $row["jumlah_anggota"]. " </td>
				<td>" . $row["status_kk"]. " </td>
				</tr>" ;}
} else {
    echo "0 results";
}
$conn->close();
?>
</table>
<div class="footer">
  	<p>Contact US : +62 85601754527</p>
</div>
   	
</div>	
</body>
</html>