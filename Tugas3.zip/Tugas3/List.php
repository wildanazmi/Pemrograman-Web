<!doctype html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>

	<title>List</title>
	<link rel="stylesheet" type="text/css" href="css/style.css">
</head>

<body>
	
		<div class="main">
			<ul>
				<li><a href="Home.php">Home</a></li>
				<li><a href="List.php">List RT / RW</a></li>
				<li><a href="Keluarga.php">Lihat Data Keluarga</a></li>
				<li><a href="arsip.php">Arsip</a></li>
				<li><a href="Iuran.php">Tagihan Iuran</a></li>
				<li><a href="mutasi.php">Mutasi</a></li>
				<li><a href="login2.php">Logout</a></li>
				<li><a href="settingpass.php">Akun</a></li>	
			</ul>
		</div>
		
		<div class="list">
		<h2>List Nama Group RW 01</h2>
		
		<ul>
			<li><a href="RT01RW01.php">1. RT 01 / RW 01</a></li>
			<li><a href="RT02RW1.php">2. RT 02 / RW 01</a></li>
			<li><a href="RT03RW1.php">3. RT 03 / RW 01</a></li>
		</ul><br><p><strong>-------------</strong></p><br>
		
		<h2>List Nama Group RW 02</h2>
		<ul>
			<li><a href="RT01RW02.php">1. RT 01 / RW 02</a></li>
			<li><a href="RT02RW02.php">2. RT 02 / RW 02</a></li>
			<li><a href="RT03RW02.php">3. RT 03 / RW 02</a></li>
			</ul>
	</div>
	
	
		
<br><br><br>
<script src="js/main.js"></script>
	<div class="footer">
  	<p>Contact US : +62 85601754527</p>
</div>

	</div>	
</body>
</html>
