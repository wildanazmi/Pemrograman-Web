<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title> Arsip </title>

<style type= "text/css">
h1{
	text-align: center;
	padding-top: 50px;
	font-size: 30px;}


.list {
	font-size: 20px;
}
	
</style>
<link rel="stylesheet" type="text/css" href="css/style.css">
</head>

<body>

		<div class="main">
			<ul>
				<li><a href="Home.php">Home</a></li>
				<li><a href="List.php">List RT / RW</a></li>
				<li><a href="keluarga.php">Lihat Data Keluarga</a></li>
				<li><a href="arsip.php">Arsip</a></li>
				<li><a href="Iuran.php">Tagihan Iuran</a></li>
				<li><a href="mutasi.php">Mutasi</a></li>
				<li><a href="login2.php">Logout</a>
				<li><a href="settingpass.php">Akun</a></li>
			</ul>
		</div>
		<h1> Arip Surat </h1>
		<div class="list">
			<ul>
				<li><a href="surat_masuk.php"> 1. Buat Arsip Surat</a></li>
				<li><a href="lihat_arsip.php"> 2. Lihat Arsip Surat</a></li>
				<li><a href="https://drive.google.com/drive/folders/1Pn0WHvtSwjiUAHBHdR7anOqy42Aa5LPF?usp=sharing">3. Cetak Template Surat Undangan/Pemberitahuan</a></li>
			</ul>
			
		</div>

	</body>

<div class="footer">
  	<p>Contact US : +62 85601754527</p>
</div>

	</html>
	